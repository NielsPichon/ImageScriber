function dft(x) {
  const X = [];
  const N = x.length;
  for (let k = 0; k < N; k++) {
    let re = 0;
    let im = 0;
    for (let n = 0; n < N; n++) {
      const phi = (TWO_PI * k * n) / N;
      re += x[n] * cos(phi);
      im -= x[n] * sin(phi);
    }
    re = re / N;
    im = im / N;

    let freq = k;
    let amp = sqrt(re * re + im * im);
    let phase = atan2(im, re);
    X[k] = {
      re,
      im,
      freq,
      amp,
      phase
    };
  }
  return X;
}


function curveDFT(pixels) {
  let x = [];
  let y = [];
  for (let i = 0; i < pixels.length; i++) {
    x.push(pixels[i].x);
    y.push(pixels[i].y);
  }

  let dftX = dft(x);
  let dftY = dft(y);
  return [dftX, dftY];
}

function lowPass(pix, maxFreq) {
  let sorted = [];
  arrayCopy(pix, 0, sorted, 0, min(maxFreq, pix.length));
  return sorted;
}