onmessage = function(msg) {
   
   print("got msg. Starting work");
   
  //resize the image
  if (msg.img.width > msg.img.height){
	msg.img.resize(msg.size, 0);
  }
  else
  {
	msg.img.resize(0, msg.size);
  }
	
	//compute the contour
  contour = findContour(msg.img, msg.threshold)
  contourPixels = getContourList(contour, msg.threshold);
  contourPixels.splice(0, 0, createVector(0, height / 2));
  contourPixels = decimate(contourPixels, msg.distThreshold, 5);
  contourPixels = centerContour(contourPixels);

  //compute the contour dft
  [fourierX, fourierY] = curveDFT(contourPixels);

  fourierX.sort((a, b) => b.amp - a.amp);
  fourierY.sort((a, b) => b.amp - a.amp);	
  
  let workerResult = {fourierX, fourierY};
  
  print("Sending Data Back");
  postMessage(workerResult);
}