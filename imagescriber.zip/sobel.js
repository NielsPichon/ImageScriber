function sobelFilter(img) {
  let filtered = createImage(img.width, img.height);
  filtered.loadPixels();
  img.loadPixels();
  for (let x = 1; x < filtered.width - 1; x++) {
    for (let y = 1; y < filtered.height - 1; y++) {
      let gray = abs(-brightness(img.get(x - 1, y)) + brightness(img.get(x + 1, y))- brightness(img.get(x, y - 1)) + brightness(img.get(x, y + 1)));
    filtered.set(x, y, color(gray));
  }
}
filtered.updatePixels();
return filtered;
}

function sobelFilter2(img) {
  let filtered = createImage(img.width, img.height);
  filtered.loadPixels();
  img.loadPixels();
  for (let x = 2; x < filtered.width - 2; x++) {
    for (let y = 2; y < filtered.height - 2; y++) {
      let gray = abs(brightness(img.get(x - 2, y)) + brightness(img.get(x + 2, y)) - 2 * brightness(img.get(x, y)) + brightness(img.get(x, y - 2)) + brightness(img.get(x, y + 2)) - 2 * brightness(img.get(x, y)));
      filtered.set(x, y, color(gray));
    }
  }
  filtered.updatePixels();
  return filtered;
}

function findContour(img, threshold) {
  let filteredImg = sobelFilter(img);
  filteredImg.filter(THRESHOLD, threshold);
  let dilateSize = 3;
  for (let i = 0; i < dilateSize; i++) {
    filteredImg.filter(DILATE);
  }
  for (let i = 0; i < dilateSize; i++) {
    filteredImg.filter(ERODE);
  }
  return filteredImg;
}

function getContourList(contour, threshold) {
  //record all white pixels
  contour.loadPixels();
  let pix = [];
  for (let x = 1; x < contour.width - 1; x++) {
    for (let y = 1; y < contour.height - 1; y++) {
      if (red(contour.get(x, y)) > threshold * 255) {
        pix.push(createVector(x, y));
      }
    }
  }
  //sort by proximity to the image center line  
  pix.sort((a, b) => abs(a.y - contour.height / 2) - abs(b.y - contour.height / 2));


  let i = 0;
  while (i < pix.length - 1) {
    //sort by proximity to previous pixel
    let min = sqrt(pow(width, 2) + pow(height, 2));
    let pointIdx = i + 1;
    for (let j = i + 1; j < pix.length; j++) {
      let dist = sqrt(pow((pix[j].x - pix[i].x), 2) + pow((pix[j].y - pix[i].y), 2));
      if (dist < min) {
        min = dist;
        pointIdx = j;
      }
    }

    let closestPoint = pix[pointIdx].copy();
    pix[pointIdx].x = pix[i + 1].x;
    pix[pointIdx].y = pix[i + 1].y;
    pix[i + 1].x = closestPoint.x;
    pix[i + 1].y = closestPoint.y;

    i++;
  }

  return pix;
}

function decimate(pix, distThreshold, amount) {
  for (let i = 0; i < amount; i++) {
    let buffer = [];
    for (let j = 0; j < pix.length; j++) {
      buffer.push(pix[j]);
      if (j < pix.length - 1) {
        let dist = sqrt(pow((pix[j + 1].x - pix[j].x), 2) + pow((pix[j + 1].y - pix[j].y), 2));
        if (dist < distThreshold) {
          j++
        }
      }
    }
    pix = [];
    arrayCopy(buffer, 0, pix, 0, buffer.length);
  }
  return pix;
}


function decimate2(pix, distThreshold) {
  for (let i = 0; i < pix.length; i++) {
    let buffer = [];
    for (let j = i+1; j < pix.length; j++) {
      
      let dist = sqrt(pow((pix[j].x - pix[i].x), 2) + pow((pix[j].y - pix[i].y), 2));
      if (dist > distThreshold) {
          buffer.push(pix[j]);
      }
    }
    pix = [];
    arrayCopy(buffer, 0, pix, 0, buffer.length);
  }
  return pix;
}


function centerContour(pix) {
  let meanX = 0;
  let meanY = 0;
  for (let i = 0; i < pix.length; i++) {
    meanX += pix[i].x;
    meanY += pix[i].y;
  }

  meanX = meanX / pix.length;
  meanY = meanY / pix.length;

  for (let i = 0; i < pix.length; i++) {
    pix[i].x -= meanX;
    pix[i].y -= meanY;
  }

  return pix;
}